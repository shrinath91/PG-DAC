









// Create a class Customer having emailid and address. Create a subclass ReCustomer by 
// adding data member as reg no. Accept the type of
// the customer from user and accordingly accept the information from the user. 
// Write method giveDiscount() in Customer and RegCustomer
// which needs input parameter as shopping price. Give no discount to Customer 
// but give 5% discount ReCustomer and display the final price.