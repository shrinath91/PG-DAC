#include<iostream>
using namespace std;

class Math1
{
  
    private:
        int Addition(int num1, int num2)
        {
            return num1+num2;
        }
        int Substraction(int num1, int num2)
        {
            return num1-num2;
        }
        void area(int a)
        {
            cout<<"Area of circle!!\n";
        }

};