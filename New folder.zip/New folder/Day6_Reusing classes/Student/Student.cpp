#include"Student.h"
int Student:: cnt=0;

Student::Student()////////////////////////////constructor
{

}
// Student(int, Cstring, Date, Date);
Student::Student(const char *s, int d1,int m1,int y1, int d2,int m2,int y2)
{

}
Student::Student(Student &obj)/////////////////////////copy
{

}
Student::~Student()
{

}

void Student::setData(const char* s, int d1,int m1,int y1, int d2,int m2,int y2)
{

}
void Student::display()
{
}