package a1_Linked_list_int;

public class Node {
	int data;
	Node next;
	public Node() {
		super();
		this.data = '\n';
		this.next = null;
	}
	
	public Node(int data) {
		super();
		this.data = data;
		this.next = null;
	}

	public String toString() {
		return data+ "";
	}
	
	
	
	
	
	
	

}
