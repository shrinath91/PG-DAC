#include"Student.h"
int main()
{
    char ch;
    int d1,m1,y1;
    int d2,m2,y2;
    cout<<"Enter Data of 5 Students: \n";
    for(int i=0; i<5; i++)
    {
        cout<<"Enter name of student: ";
    }
}
